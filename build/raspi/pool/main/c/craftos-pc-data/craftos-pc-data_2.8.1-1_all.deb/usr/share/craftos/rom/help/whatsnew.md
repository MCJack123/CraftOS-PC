New Features in CraftOS-PC v2.8.1:

* Updated CC:T version to 1.109.3
  * Fix trailing-comma on method calls (e.g. `x:f(a, )`) not using our custom error message.
* Fixed high memory usage caused by ropes & substrings
* Fixed crash when closing WebSocket server
* Fixed CCEmuX plugin failing to load

Type "help changelog" to see the full version history.
