The speaker program plays audio files using speakers attached to this computer.

## Examples:
- `speaker play example.dfpwm left` plays the "example.dfpwm" audio file using the speaker on the left of the computer.
- `speaker stop` stops any currently playing audio.